#!/usr/bin/env python3
"""Remote script executed by the authenticated Colab CLI T4 handoff."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path


ROOT = Path("/content/ai-hardware-analysis")
SOFTWARE = ROOT / "analog-in-memory-ai-inference/software-architecture"
OUTPUT = Path("/content/gpt2-sar-t4")


def run(command: list[str], cwd: Path) -> None:
    print("$ " + " ".join(command), flush=True)
    subprocess.run(command, cwd=cwd, check=True)


def main() -> None:
    if not (ROOT / "analog-in-memory-ai-inference").exists():
        raise SystemExit(f"missing unpacked repository: {ROOT}")
    run([sys.executable, "-m", "pip", "install", "-q", "torch", "transformers", "huggingface_hub"], SOFTWARE)
    run([sys.executable, str(SOFTWARE / "colab/run_profile_driven_gpt2_colab.py"),
         "--repo-root", str(ROOT), "--output", str(OUTPUT), "--fetch-model",
         "--execute-model", "--device", "cuda"], ROOT)
    receipt = json.loads((OUTPUT / "colab-receipt.json").read_text())
    print(json.dumps({"status": "passed", "device": receipt.get("environment", {}).get("device"),
                      "receipt": str(OUTPUT / "colab-receipt.json")}), flush=True)


if __name__ == "__main__":
    main()
