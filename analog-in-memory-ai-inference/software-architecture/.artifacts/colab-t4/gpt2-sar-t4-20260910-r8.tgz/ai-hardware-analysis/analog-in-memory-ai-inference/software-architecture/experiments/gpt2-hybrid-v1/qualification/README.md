# GPT-2 converter qualification matrix

This is the first execution receipt for the hardware qualification goal. It
uses the same extracted converter candidate identity as the physical repair
evidence and exercises four input differentials:

```text
-100 mV, -0.1529705854 mV, +0.1529705854 mV, +100 mV
```

The current extracted transient run measured all four cases. Three cases pass
the polarity check and zero cases pass the declared 0.9 V logic-margin gate.
The result is useful characterization evidence; it is not converter signoff.

Run the matrix again from the EDA repository with:

```bash
python3 scripts/run_active_converter_macro_extracted_transient.py \
  --candidate-dir evidence/aimc-simulator-adapters/recovery-20260909/contact-rebuild-v3 \
  --input-diffs-mv -100 -0.1529705854 0.1529705854 100 \
  --timeout-seconds 120
```

The runner's output JSON is copied by the physical-gate importer into this
experiment's handoff directory. The next matrix revision must add reset and
repeated-history sequences, supply/common-mode sweeps, PVT or an explicit
model-availability record, noise/mismatch, settling, and full converter code
transfer before the analog path can be authorized.

The first seven-profile repeated-history screen is now recorded in
`matrix.json`: all seven profiles completed and passed the local hold/reset
diagnostic, but none produced a legal waveform under the screen contract. This
is useful characterization evidence and keeps repeated-history and PVT marked
`screened_not_qualified`.

The latch-only rerun separated the receiver from the issue. Hold and reset
checks pass on every cycle, while the observable output briefly undershoots to
`-0.07156 V`; that rail excursion is the current failure mechanism. The
legality check now covers only `out_p` and `out_n` (and receiver outputs when a
receiver is present), while all internal extrema remain in the result for
diagnosis. The repair status is now `repair_screen_passed_combined_screen_passed`.

Every result keeps separate fields for polarity, logic margin, timeout,
energy scope, and claim boundary. A passing polarity row never promotes the
whole converter or the GPT-2 workload to an analog hardware claim.

A reset-timing repair screen then applied `0.5 ns` reset advance and a `1000
ps` clock fall to the latch-only path. All seven process/temperature profiles
completed with legal observable waveforms and passing four-cycle rows. The
screen is recorded as `screen_passed_not_qualified`: it still requires the
combined converter, receiver loading, noise/mismatch, settling and full code
transfer gates.

The repaired timing condition also passes the combined extracted latch/receiver
path for four alternating cycles. The receiver’s extrema are `-2.52 mV` and
`1.80180 V`, inside the explicit `5 mV` waveform tolerance, and all polarity,
hold, reset and receiver checks pass. This is recorded as
`combined_screen_passed_not_qualified`; it does not close the full converter
or analog inference gates.

The matrix now also links the converter-side screens. The 10-bit row-DAC
settling fixture passes three low/mid/high codes within half an LSB (worst
error `176.7 uV` after `4 ns`), and the simple 12-bit SAR readout fixture
passes three readout levels across twelve comparisons. Differential sampling
passes the two common-only cases but intentionally fails the injected-mismatch
case at `300 uV`, which is above the 12-bit half-LSB target. These are useful
block-level SPICE and topology results; they remain open for the extracted
transistor converter, mismatch/noise, PVT, and continuous multi-cycle transfer
proof needed for an analog claim.
Shared-converter loading also passes four simple mux-load cases, including up
to 32 active loads, and the supply-energy fixture reports positive DAC, mux,
and ADC energy for three cases (worst total `4.273 pJ`). Those numbers are
early budgeting evidence only: they exclude input/clock drivers, biasing,
memory movement, accumulation, and the extracted macro path.

The first bounded physical DAC/comparator SAR smoke run was attempted with one
input code and a `5 s` per-transient limit. The first transistor-level
comparison timed out before producing a measurement. The matrix records this
as a runtime/convergence gate, so the simple-load passes are not promoted to a
physical converter claim. The next engineering action is to make that
transient converge or reduce the deck to a validated one-bit extracted slice
before repeating the full SAR sequence.

There is already a stronger nominal one-bit artifact: the physical Sky130
DAC/comparator sweep measured all 16 four-bit trial codes with correct
polarity. The matrix links it as a one-bit transfer pass. It gives us a
validated starting point for the SAR integration, while the failed smoke run
shows that the retained-bit sequence still needs a convergence-friendly deck.

The repository also contains a continuous physical SAR candidate that completes
five decision-dependent conversions in one transient, with all five nominal
results correct. A seeded 1% capacitor-variation stress set measured 97 of 100
trials; 95 passed the complete map and all 97 measured trials passed the legal
bottom-plate checks. This advances the converter gate substantially, but it is
still a candidate result: foundry Monte Carlo, comparator noise/offset, PVT,
and extracted-layout acceptance remain open.

Representative calibrated PVT evidence now covers 25 measured cases across
five process/supply/temperature corners with 25/25 correct polarity and no
timeouts. A separate 20-case comparator-disturbance stress envelope passes 17
cases, with the boundary between passing and failing uncertainty near
`0.153–0.158 mV`. These results tighten the operating envelope but do not
replace transistor-level noise/offset yield evidence.

The current bounded latch-free transistor offset smoke artifact attempts one
`+0.1 mV` differential and times out before measurement. The runner now
supports separate output stems, input subsets, timeout, relative tolerance,
and gmin controls so convergence experiments do not overwrite prior evidence.
Earlier measured offset rows remain useful historical characterization, but the
current canonical artifact is treated as unavailable until rerun end to end.

Five convergence configurations (Gear/Trap, higher gmin, relaxed tolerance,
UIC, and a coarser timestep) were tested on isolated cases. All still timed
out for the positive or zero sign, so this is now recorded as a numerical deck
diagnostic rather than repeatedly presented as missing measurement data.

The offset/noise proxy was rerun against the current source fixture and found
zero successful source rows because that fixture is timing out. The script now
records this explicitly instead of crashing or inventing a margin. A named
converter noise candidate still reports `851.121 uV` RMS within its behavioral
budget, but it is not extracted device-noise evidence.

A minimal DC-biased preamp sanity deck was also tested with the latch removed,
fixed sample controls, and explicit node leakage. All three signed inputs still
timed out, confirming the convergence issue is present before regeneration and
is structural to this model/deck combination.

To isolate the environment, a one-NMOS Sky130 operating-point probe was run
with no capacitors, clocks, or transient analysis. It also timed out at `30 s`.
This is now recorded as a model/runtime availability gate; until it completes,
new transient results cannot be interpreted as circuit behavior.

The latest host preflight captured a 1-minute load ratio of `15.69`. Even though
the narrow simulator-process counter was zero, other long-running workloads
are saturating the machine, so the minimal model probe is not a clean PDK
verdict yet; the next probe must run on an available host window.

An explicitly biased reference differential pair was then tested without any
floating storage nodes or latch devices. Its single zero-differential case
also timed out after `60 s`, so the issue is broader than the candidate latch
topology. This points to the local Sky130 transient/model execution path as
the next infrastructure issue to isolate before further circuit claims.

The ngspice executable itself passes a resistor-only operating-point control in
under two seconds while the host is contended. This isolates the delay to the
Sky130 model/PDK path (or its interaction with host load), rather than the
ngspice binary or process launch.

The Colab CLI currently exposes two authenticated T4 sessions. The hardware
probe should be moved to one of those sessions only after installing or
uploading the pinned Sky130 model bundle and ngspice deck; a GPU session by
itself does not provide the PDK. The existing GPU handoff runbook remains the
reference for session setup.

The corrected model-load probe now includes the Sky130 library plus a simple
resistor operating point, so it exercises the library includes without any
Sky130 device. It still times out at `30 s`; the prior no-analysis return code
was replaced by this valid timeout result.

The dedicated Colab session `sky130-runtime-probe` then installed ngspice,
verified the bundle hash, unpacked the `libs.ref` dependencies, and passed a
nominal `sky130_fd_pr__nfet_01v8` operating point in `11.264 s`. This closes the
PDK runtime gate remotely; the local timeout remains an environment result and
is not used to reject the Colab circuit path.

The first coupled physical circuit run in Colab measured two representative
DAC/comparator trial codes with `2/2` correct polarity and no timeouts. A
fresh T4 session then ran the complete four-bit code sweep sequentially:
`16/16` codes measured, `16/16` correct polarity, and zero timeouts. This
reopens the physical converter path on a clean runtime and closes the complete
one-bit code-sweep gate. It is still not a full retained-bit SAR, PVT,
mismatch/noise, extracted-layout, or GPT-2 tile acceptance result.

The subsequent fresh T4 Colab run completed five representative retained-bit
SAR conversions: `20/20` physical comparator decisions measured, `5/5`
conversions correct, and zero timeouts. Each decision is a fresh physical
transient reset, so continuous clock-to-clock state retention and the PVT,
mismatch/noise, extracted-layout, and GPT-2 tile gates remain open.

The first remote continuous-deck diagnostic converged but returned code `0`
for the code-`2` reference. The five-conversion continuous run exposed a
ngspice timestep collapse at a behavioral gate branch. The gate driver now
supports a smooth transition through `AIMC_CONTINUOUS_GATE_SLOPE` for
convergence work; it has not yet produced an accepted continuous SAR result.
The deck now also supports explicit finite-rise/fall PWL timing through
`AIMC_CONTINUOUS_PWL_RISE_NS`, the preferred next control topology because it
reaches full rail values without ideal behavioral time steps.

The first complete remote continuous-SAR pass uses 50 ps PWL control edges and
100 ps decision-clock edges. It measures and decodes the representative map
`0, 2, 4, 6, 7` exactly (`5/5` conversions, zero timeouts) in one continuous
Sky130 transient. This closes nominal continuous-SAR behavior; robustness and
model-to-tile integration remain open.

The first continuous robustness corner also passes: at SS, −20 °C, and 1.62 V,
the widened 200 ps PWL and clock controls produce `5/5` correct conversions
with zero timeouts. The remaining TT/FF/SF/FS corners and mismatch/noise
campaign are still open.

The remaining corner sweep measured all three additional continuous runs. SF
passes `5/5` with the nominal map; FF at 85 °C/1.98 V decodes
`2,6,7,7,8`, and FS decodes `0,4,5,6,7`. Those are measured corner maps, not
timeouts, and show that FF/FS need corner-specific calibration before a full
PVT claim.

A fresh five-trial fixed-seed mismatch campaign using the current `1.8x` LSB
calibration completed all five transients and kept every bottom plate legal,
but every trial failed the retained-code map in the same pattern
`[1,4,6,7,8]`. This confirms the population harness and exposes a repeatable
functional sensitivity of the current candidate; it is still a seeded
capacitor stress model, not foundry mismatch yield.

The FS bit-1 trajectory comparison bounds the next calibration target:
changing bit-1 from `0.75x` to `0.5x` first changes decisions in conversions 3
and 4, with up to `151.7 mV` DAC and `324.9 mV` preamp trajectory shifts. The
next FS experiment should tune the later bit paths or isolate their charge
transfer rather than adjust the code-2 reference.

`sar-calibration-ranking.json` now ranks 438 checked-in continuous-SAR receipts
(296 complete map passes) by their exact control settings. These are historical
schematic results; the ranking is a selection aid, not a PVT or mismatch yield
claim.

The corrected authenticated T4 handoff is archived under
`runs/gpt2-sar-t4-20260910-r7/`. It ran the pinned revision on `device: cuda`
with synchronized timing. The ADC12 profile reached 100% teacher-forced argmax
agreement and 4/4 exact generations (`0.0047839` NLL increase); the evaluator
and CUDA-required receipt checkers both pass. The 8-bit ADC profile remains a
quality failure, and this is still numerical profile evidence rather than an
analog hardware claim.

`cpu-cuda-comparison.json` compares the synchronized CPU control with T4 r7 on
the same fixture. The ADC12 profile has median reference time `1,791.4 ms` on
CPU versus `408.4 ms` on T4 (about `4.39×`), while deterministic quality fields
match. The noisy profile is stochastic and is intentionally excluded from
bitwise parity checks. These are device-execution numbers, not analog speedup
or energy evidence.

`t4-dispatch-decision.json` is the current end-to-end decision package. It
joins the T4 ADC12 quality result, the `408.39 ms` median T4 reference time,
and the fail-closed converter routes. Zero vectors are authorized for analog
execution; native digital GPU execution remains authoritative until physical
converter and energy measurements close.

The FF-derived remap was then frozen and tested against three holdouts in
`sar-code-remap-holdout-ff.json`. It passed `0/3`: FS contains a collision,
mismatch produces codes outside the FF domain, and split-MSB changes the code
scale. Calibration therefore does not generalize across this envelope; the
next circuit experiment must use per-corner/per-converter calibration or repair
the conversion path before workload promotion.

The complementary per-converter test fits a remap on mismatch trial 000 and
validates it on trials 001–004. It passes `4/4` because all five trials share
the same observed code pattern (`[1,4,6,7,8]`). This is enough to model a
bounded digital label correction for that campaign; it does not repair the
underlying analog settling error or establish yield, so analog placement stays
blocked.

`converter-dispatch-policy.json` turns the evidence into runtime behavior. It
routes nominal/SS/SF/FF and unknown cases to digital fallback, rejects FS on its
code collision, and exposes the mismatch remap only as a bounded digital
correction candidate. Unknown codes and collisions fail closed.

`converter-dispatch-simulation.json` applies those routes to all 162 workload
vectors. FF, FS, and unknown scenarios require fallback; the bounded mismatch
scenario exposes all 162 vectors to digital code correction, with zero vectors
authorized for analog execution. This is the software control behavior the
Colab workload replay will exercise.

The Colab receipt also runs `check_converter_dispatch_simulation.py`, which
verifies scenario coverage, vector conservation, zero analog-authorized
vectors, and fail-closed FF/FS/unknown routing before any model execution.

The first full pinned-model run is archived under
`runs/20260910-profile-driven-colab/`. Its `dac10_weight8_adc12` numerical
variant reaches 100% teacher-forced argmax agreement and 4/4 exact generations
with an NLL increase of `0.0046545` nats/token; the conservative 8-bit and noisy
12-bit variants fail the provisional screen. The evaluator checker passes, but
the run is CPU numerical emulation and does not measure analog hardware cost.

After adding explicit device selection, the verified rerun is archived under
`runs/20260910-profile-driven-device-aware/`; its source-hash checker passes.
Use `--device cuda` in Colab to produce the matched T4 version from the same
runner and fixture.

The complete fresh-runtime instructions are in
`software-architecture/colab/README.md`.

The same package now includes `real-model-workload-hardware-contract.json`,
which joins the existing Tesla T4 serving characterization to the GPT‑2
workload boundary. It records 630.24 MB maximum observed peak memory and keeps
the decision focused on decode-first digital runtime optimization before any
analog placement. The T4 evidence is contextual rather than a matched
analog-versus-GPU benchmark.

`profile-driven-workload-trace.json` converts the saved GPT-2 projection run
into a phase-level schedule: 162 vectors, 2,985,984 DAC conversions, 2,985,984
ADC conversions, array evaluations, digital accumulation, and boundary bytes.
It remains explicitly `digital_fallback_only`; the artifact is the input to the
next Colab holdout run, not analog timing or energy evidence.

`profile-driven-transformer-contract.json` now binds the qualification state to
the frozen GPT-2 `transformer.h.0.mlp.c_fc` projection. One vector requires
2,359,296 MACs, 18,432 DAC conversions, 18,432 ADC conversions, 288 array
evaluations, and 15,360 digital partial-sum additions under the current 128×128
tile schedule. Native digital fallback remains authoritative. The next Colab
run fits remaps on calibration references, validates them on new mismatch
references, and evaluates the unchanged GPT-2 contexts with conversion,
fallback, movement, latency, and energy fields recorded.

For a Colab replay, clone the repository into `/content/ai-hardware-analysis`
and run the bundled entry point:

```bash
python3 analog-in-memory-ai-inference/software-architecture/colab/run_profile_driven_gpt2_colab.py \
  --repo-root /content/ai-hardware-analysis \
  --output /content/gpt2-sar-qualification-receipt
```

Add `--execute-model` only when the pinned model snapshot and required local
evidence are present. The default run validates the contract and emits the
operation trace without silently inventing analog timing or energy.

On a networked Colab runtime, add `--fetch-model --execute-model` to download
the exact fixture revision first and then run the evaluator. The receipt records
the model snapshot and any execution failure instead of substituting another
revision.

The evaluator now synchronizes CUDA before and after each measured call, so the
same runner can produce valid device timing on a Colab T4. The synchronized CPU
control is archived under `runs/20260910-profile-driven-synchronized/` and its
source-hash checker passes.

The full orchestration control is archived under
`runs/20260910-profile-driven-integrated/`. It executes the model, contract
checks, dispatch simulation, and remap attachment in one receipt; all software
checks pass on CPU. The same command with `--device cuda` is the required T4
run.

When present, the entry point also attaches the per-converter mismatch result
(`4/4` holdouts) to the receipt. That result is scoped to the fixed mismatch
campaign; it does not override the global PVT and physical qualification gates.

The contract is checked with:

```bash
python3 scripts/check_profile_driven_transformer_contract.py \
  experiments/gpt2-hybrid-v1/qualification/profile-driven-transformer-contract.json
```

The split-MSB isolation replay also completed in Colab but worsened the exact
failing seed to `[0,10,12,12,14]` despite legal bottom plates. That topology is
rejected for the current candidate; per-bit isolation needs a controlled
charge-transfer design rather than simply splitting the largest plate.

The circuit profile is now imported through `circuit-profile-import.json`. The
handoff preserves four supported cases and three open cases, while explicitly
setting `placement_allowed=false`; model experiments cannot silently turn
schematic evidence into an analog hardware claim.

The ranking now groups receipts by inferred process corner. The best available
FS setting is `bit1=0.75x`, `LSB=1.8x`, but it still achieves only `4/5`
representative codes (`[0,4,4,6,7]`); it is a bounded calibration candidate,
not a passing FS envelope.

`sar-code-remap-contract.json` makes the software handoff rule executable:
remapping is allowed only when a converter's observed codes are monotonic,
one-to-one, and cover the held-out target set. The FF reference case satisfies
that contract; FS has a code collision and the seeded mismatch case produces
out-of-set codes (`[1,4,6,7,8]`), so both remain rejected. This is a guarded
digital calibration interface, not a repair of analog error or a hardware-yield
claim.
